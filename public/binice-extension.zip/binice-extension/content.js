// Reflekt – Content Script
(function () {
  'use strict';

  var currentComment = '';
  var activeBox = null;
  var analysisResult = null;
  var selectedTone = 'saklig';
  var currentIntention = '';
  var _lastSuggestion = '';
  var history = [];

  var BEE_URL = chrome.runtime.getURL('binice.png');

  // ─── Block Messenger ────────────────────────────────────────────────────────
  function isMessenger() {
    var p = window.location.pathname;
    return p.startsWith('/messages') || p.startsWith('/t/');
  }

  // ─── Init ───────────────────────────────────────────────────────────────────
  function init() {
    if (isMessenger()) return;
    var observer = new MutationObserver(attachToCommentForms);
    observer.observe(document.body, { childList: true, subtree: true });
    attachToCommentForms();
  }

  function attachToCommentForms() {
    if (isMessenger()) return;
    var sels = [
      '[aria-label="Skriv en kommentar\u2026"]',
      '[aria-label="Skriv en kommentar"]',
      '[aria-label="Write a comment\u2026"]',
      '[aria-label="Write a comment"]',
      '[aria-label="Kommentera\u2026"]',
      '[aria-label="Kommentera"]',
      '[aria-label="Comment"]',
      '[aria-label="Comment\u2026"]',
      '[aria-placeholder="Skriv en kommentar\u2026"]',
      '[aria-placeholder="Write a comment\u2026"]',
      '[aria-placeholder="Comment\u2026"]',
      '[data-lexical-editor="true"]'
    ].join(',');
    document.querySelectorAll(sels).forEach(attachBox);
    document.querySelectorAll('[contenteditable="true"]').forEach(function(box) {
      if (box.dataset.reflektAttached) return;
      if (box.closest('[role="complementary"]')) return;
      var inArticle = !!box.closest('[role="article"]');
      var inForm = !!box.closest('form');
      var nearTop = box.getBoundingClientRect().top < 200;
      if (!inArticle && !inForm && nearTop) return;
      attachBox(box);
    });
  }

  function attachBox(box) {
    if (box.dataset.reflektAttached) return;
    box.dataset.reflektAttached = 'true';
    box.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        if (_releasing) return; // our own released Enter, let it through
        var text = box.innerText.trim();
        if (text.length > 3) {
          currentComment = text;
          activeBox = box;
          history = [];
          currentIntention = '';
          e.preventDefault();
          e.stopPropagation();
          checkAndTrigger(text);
        }
      }
    }, true);
  }

  // ─── Pre-check ──────────────────────────────────────────────────────────────
  // ─── Pre-check ──────────────────────────────────────────────────────────────
  var _releasing = false;

  async function checkAndTrigger(text) {
    var stored = await chrome.storage.local.get('apiKey');
    var apiKey = stored.apiKey;
    if (!apiKey) { releaseEnter(); return; }
    var flag = false;
    try {
      var res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 10,
          messages: [{ role: 'user', content: 'Är kommentaren aggressiv, nedvärderande, hånfull eller hotfull mot en person eller mot det personen säger, tycker eller bidrar med?\nSvara ENDAST: JA eller NEJ.\n\nNEJ för: neutral, positiv, kortfattad, faktapåstående, fråga, oenig men respektfull, beröm, uppmuntran. Saklig kritik av ett argument utan nedlåtande ton ger NEJ. Blandade kommentarer med beröm OCH mild kritik ger NEJ.\nJA för: direkta personangrepp eller skällsord (t.ex. idiot, dum i huvudet, skäms), hot, uttalad fientlighet, samt nedlåtande eller föraktfulla omdömen om personens åsikt, intelligens eller bidrag (t.ex. idiotisk åsikt, dumt sagt, fattar du ingenting). Även om kommentaren innehåller något positivt: om den även innehåller ett angrepp ger det JA.\n\nKommentar: "' + text.replace(/"/g, '\\"') + '"' }]
        })
      });
      if (res.ok) {
        var d = await res.json();
        flag = (d.content || []).map(function(b) { return b.text || ''; }).join('').trim().toUpperCase().startsWith('JA');
      } else { flag = false; }
    } catch(e) { flag = false; }
    if (flag) { showStep2(); } else { releaseEnter(); }
  }

  // Release blocked Enter using _releasing flag to prevent loop
  function releaseEnter() {
    if (!activeBox || !document.contains(activeBox)) return;
    if (_releasing) return;
    _releasing = true;
    activeBox.focus();
    activeBox.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'Enter', keyCode: 13, which: 13,
      bubbles: true, cancelable: true
    }));
    setTimeout(function() { _releasing = false; }, 600);
  }


  // ─── Overlay ────────────────────────────────────────────────────────────────
  // Create overlay+panel once, reuse forever. Click listener added exactly once.
  function ensureOverlay() {
    if (document.getElementById('reflekt-panel')) return;
    var overlay = document.createElement('div');
    overlay.id = 'reflekt-overlay';
    var panel = document.createElement('div');
    panel.id = 'reflekt-panel';
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    panel.addEventListener('click', handleClick);
    // Block scroll on the overlay itself
    overlay.addEventListener('wheel', function(e) { e.preventDefault(); }, { passive: false });
    overlay.addEventListener('touchmove', function(e) { e.preventDefault(); }, { passive: false });
  }

  function paint(html) {
    ensureOverlay();
    var panel = document.getElementById('reflekt-panel');
    panel.innerHTML = html;
    // Auto-resize textareas (oninput = no stacking)
    panel.querySelectorAll('textarea').forEach(function(ta) {
      ta.style.height = 'auto';
      ta.style.height = (ta.scrollHeight + 2) + 'px';
      ta.oninput = function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight + 2) + 'px';
      };
    });
  }

  function showScreen(html, name) {
    history.push(name);
    paint(html);
  }

  // renderOnly: update panel content WITHOUT touching history (used by goBack)
  function renderOnly(html) {
    paint(html);
  }

  function closeAll() {
    var el = document.getElementById('reflekt-overlay');
    if (el) el.remove();
    history = [];
  }

  // ─── Back navigation ────────────────────────────────────────────────────────
  function goBack() {
    history.pop(); // remove current screen name
    var prev = history[history.length - 1]; // peek at previous
    if (!prev) { closeAll(); return; }
    var htmlFns = {
      step2:       htmlStep2,
      sendConfirm: htmlSendConfirm,
      step3:       htmlStep3,
      step4:       htmlStep4,
      step5:       htmlStep5,
      writeSelf:   htmlWriteSelf,
      unchanged:   htmlUnchanged,
      binice:      htmlBinice,
      sugLoading:  htmlBinice,
      step3loading: htmlStep2,
      suggestion:  function() { return htmlSuggestion(_lastSuggestion); },
      tone:        htmlTone,
      publish:     htmlPublish
    };
    var fn = htmlFns[prev];
    if (fn) renderOnly(fn()); else closeAll();
  }

  // ─── Click handler ───────────────────────────────────────────────────────────
  function handleClick(e) {
    var b = e.target.closest('[data-a]');
    if (!b) return;
    switch (b.dataset.a) {
      case 'back':          goBack(); break;
      case 'send-orig':     showSendConfirm(); break;
      case 'do-send-orig':  pasteAndClose(currentComment); break;
      case 'to-step3':      showStep3Loading(); break;
      case 'to-step4':      showStep4(); break;
      case 'to-step5':      showStep5(); break;
      case 'to-write-self': showWriteSelf(); break;
      case 'to-binice':     showBinice(); break;
      case 'confirm-edit':  doConfirmEdit(); break;
      case 'send-unchanged':pasteAndClose(currentComment); break;
      case 'get-sug':       doGetSuggestion(); break;
      case 'use-sug':       doUseSuggestion(); break;
      case 'change-tone':   showTone(); break;
      case 'sel-tone':      selectedTone = b.dataset.tone; doLoadSuggestion(); break;
      case 'final-send':    doFinalSend(); break;
      case 'confirm-send':  pasteAndClose(currentComment); break;
    }
  }

  // ─── Paste text into Lexical editor and close ──────────────────────────────
  // Facebook uses Lexical (React-based). Standard execCommand doesn't update
  // its internal state. We use three approaches in sequence:
  // 1. React fiber nativeInputValueSetter (most reliable)
  // 2. execCommand insertText fallback
  // 3. Clipboard paste simulation
  function pasteOnly(text) {
    var target = activeBox;
    if (!target || !document.contains(target)) return;
    target.focus();

    // Step 1: Select all existing content and delete it
    try { document.execCommand('selectAll', false, null); } catch(e) {}
    try { document.execCommand('delete', false, null); } catch(e) {}

    // Also try Ctrl+A then Delete via keyboard events (Lexical may respond to these)
    try {
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true, cancelable: true }));
      target.dispatchEvent(new KeyboardEvent('keyup',   { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
    } catch(e) {}

    // Step 2: Paste new text
    var inserted = false;
    try {
      var dt = new DataTransfer();
      dt.setData('text/plain', text);
      dt.setData('text/html', '<p>' + text + '</p>');
      target.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
      inserted = true;
    } catch(e) {}

    // Fallback: select all + insert
    if (!inserted) {
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
      } catch(e) {}
    }
  }

  function pasteAndClose(text) {
    closeAll();
    var target = activeBox;
    if (!target || !document.contains(target)) return;
    target.focus();

    var inserted = false;

    // Approach 1: React fiber – find the React instance and call its onChange
    try {
      var fiberKey = Object.keys(target).find(function(k) {
        return k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance');
      });
      if (fiberKey) {
        var fiber = target[fiberKey];
        // Walk up to find the stateNode with a props.onChange
        var node = fiber;
        while (node) {
          if (node.memoizedProps && typeof node.memoizedProps.onChange === 'function') {
            // Clear the field first
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);
            // Simulate typing via nativeInputValueSetter on a temp input
            // then trigger change event on the lexical div
            var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, 'innerHTML');
            if (nativeSetter && nativeSetter.set) {
              // Set innerText directly via descriptor
              nativeSetter.set.call(target, text);
            } else {
              target.innerText = text;
            }
            node.memoizedProps.onChange({ target: { value: text } });
            inserted = true;
            break;
          }
          node = node.return;
        }
      }
    } catch(e) {}

    // Approach 2: execCommand (works on some FB versions)
    if (!inserted) {
      try {
        document.execCommand('selectAll', false, null);
        inserted = document.execCommand('insertText', false, text);
      } catch(e) {}
    }

    // Approach 3: Clipboard paste simulation (most compatible with Lexical)
    if (!inserted) {
      try {
        var dt = new DataTransfer();
        dt.setData('text/plain', text);
        dt.setData('text/html', text);
        target.dispatchEvent(new ClipboardEvent('paste', {
          bubbles: true, cancelable: true, clipboardData: dt
        }));
        inserted = true;
      } catch(e) {}
    }

    // Approach 4: Select all + type via keyboard events as last resort
    if (!inserted) {
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', keyCode: 65, ctrlKey: true, bubbles: true }));
      target.dispatchEvent(new KeyboardEvent('keyup',  { key: 'a', keyCode: 65, ctrlKey: true, bubbles: true }));
      text.split('').forEach(function(ch) {
        target.dispatchEvent(new KeyboardEvent('keypress', { key: ch, bubbles: true, cancelable: true }));
      });
    }
  }

  // ─── Helpers ────────────────────────────────────────────────────────────────
  function S(active) {
    var h = '<div class="reflekt-steps">';
    for (var i = 0; i < 4; i++) {
      if (i > 0) h += '<div class="reflekt-step-line"></div>';
      h += '<div class="reflekt-step-dot ' + (i < active ? 'done' : i === active ? 'active' : '') + '"></div>';
    }
    return h + '</div>';
  }
  function bee() {
    return '<div class="reflekt-binice-header"><div class="reflekt-bee-avatar" style="overflow:hidden;padding:0;"><img src="' + BEE_URL + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" alt="Binice"></div><div><div class="reflekt-binice-name">Binice</div><div class="reflekt-binice-role">Din reflektionsguide</div></div></div>';
  }
  function bk() { return '<button class="reflekt-btn-back" data-a="back"><span class="reflekt-back-arrow">\u2190</span> Tillbaka</button>'; }
  function esc(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function btn(a, l, c) { return '<button class="reflekt-btn ' + c + '" data-a="' + a + '">' + l + '</button>'; }
  function wrap(inner) { return '<div class="reflekt-content">' + inner + '</div>'; }

  // ─── HTML builders ───────────────────────────────────────────────────────────
  function htmlStep2() {
    return S(0) + wrap(bee() +
      '<div class="reflekt-title">Din kommentar har ett starkt tonl\u00e4ge.</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-body">Vill du ta en stund och se hur kommentaren kan uppfattas?</div>' +
      '<div class="reflekt-btn-row">' + btn('send-orig','Nej, skicka nu','reflekt-btn-no') + btn('to-step3','Ja, visa mig <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlSendConfirm() {
    return S(0) + wrap(bee() + bk() +
      '<div class="reflekt-title">Skicka utan att reflektera?</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-confirm-box">Kom ih\u00e5g att kommentaren skickas till n\u00e5gon du k\u00e4nner. \u00c4r du s\u00e4ker?</div>' +
      '<div class="reflekt-btn-row">' + btn('back','Tillbaka','reflekt-btn-yes') + btn('do-send-orig','Ja, skicka \u00e4nd\u00e5','reflekt-btn-no') + '</div>');
  }
  function htmlStep3() {
    var r = analysisResult || { highlighted_comment: esc(currentComment), reflection_question: 'Hur tror du att mottagaren upplever kommentaren?' };
    return S(1) + wrap(bee() + bk() +
      '<div class="reflekt-title">T\u00e4nk p\u00e5 hur din kommentar kan mottas.</div>' +
      '<div class="reflekt-comment-box">' + (r.highlighted_comment || esc(currentComment)) + '</div>' +
      '<div class="reflekt-nudge">' + esc(r.reflection_question) + '</div>' +
      '<div class="reflekt-body">Vill du skriva om din kommentar?</div>' +
      '<div class="reflekt-btn-row">' + btn('to-step4','Nej, forts\u00e4tt \u00e4nd\u00e5','reflekt-btn-no') + btn('to-step5','Ja, skriv om <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlStep4() {
    return S(2) + wrap(bee() + bk() +
      '<div class="reflekt-title">Du skickar kommentaren som den \u00e4r.</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-confirm-box">Kom ih\u00e5g att kommentaren skickas till n\u00e5gon du k\u00e4nner. \u00c4r du s\u00e4ker?</div>' +
      '<div class="reflekt-btn-row">' + btn('to-step5','Nej, skriv om <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + btn('confirm-send','Ja, skicka ändå','reflekt-btn-no') + '</div>');
  }
  function htmlStep5() {
    return S(2) + wrap(bee() + bk() +
      '<div class="reflekt-title">Vill du ha hj\u00e4lp att skriva om?</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-btn-row">' + btn('to-write-self','Nej, jag skriver sj\u00e4lv','reflekt-btn-no') + btn('to-binice','Ja, hj\u00e4lp mig <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlWriteSelf() {
    return S(2) + wrap(bee() + bk() +
      '<div class="reflekt-title">Skriv om din kommentar</div>' +
      '<textarea class="reflekt-textarea" id="r-edit">' + esc(currentComment) + '</textarea>' +
      '<div class="reflekt-btn-row">' + btn('confirm-edit','N\u00e4sta <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlUnchanged() {
    return S(2) + wrap(bee() + bk() +
      '<div class="reflekt-title">Du har inte \u00e4ndrat n\u00e5got</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-nudge">Kom ih\u00e5g att personen du svarar \u00e4r n\u00e5gon du k\u00e4nner. Vill du skicka som den \u00e4r?</div>' +
      '<div class="reflekt-btn-row">' + btn('to-write-self','\u2190 F\u00f6rs\u00f6k igen','reflekt-btn-no') + btn('send-unchanged','Ja, klistra in <span class="reflekt-arrow">→</span>','reflekt-btn-send') + '</div>');
  }
  function htmlBinice() {
    return S(2) + wrap(bee() + bk() +
      '<div class="reflekt-title">Vad vill du egentligen s\u00e4ga?</div>' +
      '<div class="reflekt-body">Ber\u00e4tta vad du vill f\u00f6rmedla med dina egna ord.</div>' +
      '<textarea class="reflekt-textarea" id="r-intention" placeholder="Jag vill s\u00e4ga att...">' + esc(currentIntention) + '</textarea>' +
      '<div class="reflekt-btn-row">' + btn('get-sug','Visa f\u00f6rslag <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlSuggestion(s) {
    var toneLabels = {saklig:'Saklig',vanlig:'V\u00e4nlig',informativ:'Informativ',fraga:'Fr\u00e5gande'};
    var toneLabel = toneLabels[selectedTone] || 'Saklig';
    return S(3) + wrap(bee() + bk() +
      '<div class="reflekt-title">Mitt f\u00f6rslag \u00e4r att du skriver:</div>' +
      '<div class="reflekt-suggestion-label">Binice f\u00f6resl\u00e5r – ton: ' + toneLabel + ' · du kan ändra direkt i texten</div>' +
      '<textarea class="reflekt-suggestion-editable" id="r-sug">' + esc(s) + '</textarea>' +
      '<div class="reflekt-btn-row">' + btn('change-tone','\u00c4ndra ton <span class="reflekt-arrow">\u2192</span>','reflekt-btn-no') + btn('use-sug','Anv\u00e4nd detta <span class="reflekt-arrow">\u2192</span>','reflekt-btn-yes') + '</div>');
  }
  function htmlTone() {
    var tones = [
      {id:'saklig',    img:'tone-factual.png',     n:'Saklig',     d:'Faktabaserad'},
      {id:'vanlig',    img:'tone-friendly.png',     n:'V\u00e4nlig',     d:'Empatisk'},
      {id:'informativ',img:'tone-informative.png',  n:'Informativ', d:'Pedagogisk'},
      {id:'fraga',     img:'tone-question.png',     n:'Fr\u00e5gande',   d:'\u00d6ppen dialog'}
    ];
    var TONE_URL = function(img) { return chrome.runtime.getURL(img); };
    var grid = tones.map(function(t) {
      return '<button class="reflekt-tone-btn ' + (selectedTone === t.id ? 'selected' : '') +
        '" data-a="sel-tone" data-tone="' + t.id + '">' +
        '<span class="reflekt-tone-label">' + t.n + '</span>' +
        '<img src="' + TONE_URL(t.img) + '" class="reflekt-tone-img" alt="' + t.n + '">' +
        '</button>';
    }).join('');
    return S(3) + wrap(bee() + bk() + '<div class="reflekt-title">Vilken ton vill du ha?</div><div class="reflekt-tone-grid">' + grid + '</div>');
  }
  function htmlPublish() {
    return S(3) + wrap(bee() + bk() +
      '<div class="reflekt-title">Din kommentar är klar</div>' +
      '<div class="reflekt-comment-box">' + esc(currentComment) + '</div>' +
      '<div class="reflekt-btn-row">' + btn('final-send','Klistra in <span class="reflekt-arrow">\u2192</span>','reflekt-btn-send') + '</div>');
  }
  function htmlDone() {
    return '<div style="text-align:center;padding:36px 24px;">' +
      '<div class="reflekt-check" style="background:#E18D56;border-color:#E18D56;font-size:26px;">\u2713</div>' +
      '<div style="font-size:18px;font-weight:700;margin-bottom:12px;color:var(--r-text);">Bra jobbat!</div>' +
      '<div style="font-size:14px;color:var(--r-text2);line-height:1.7;">Din kommentar är klar att skickas.<br>Tryck Enter eller klicka på skicka-pilen i Facebook.</div>' +
      '</div>';
  }

  // ─── Show functions ──────────────────────────────────────────────────────────
  function showStep2()        { showScreen(htmlStep2(),        'step2'); }
  function showSendConfirm()  { showScreen(htmlSendConfirm(),  'sendConfirm'); }
  function showStep3()        { showScreen(htmlStep3(),        'step3'); }
  function showStep4()        { showScreen(htmlStep4(),        'step4'); }
  function showStep5()        { showScreen(htmlStep5(),        'step5'); }
  function showWriteSelf()    { showScreen(htmlWriteSelf(),    'writeSelf'); }
  function showBinice()       { showScreen(htmlBinice(),       'binice'); }
  function showTone()         { showScreen(htmlTone(),         'tone'); }
  function showPublish()      { showScreen(htmlPublish(),      'publish'); }
  function showSuggestion(s)  { _lastSuggestion = s; showScreen(htmlSuggestion(s), 'suggestion'); }

  function showStep3Loading() {
    showScreen(S(1) + wrap('<div style="text-align:center;padding:30px 0 20px;"><div class="reflekt-bee-loading"><img src="' + BEE_URL + '" alt="Binice"></div><div class="reflekt-loading-dots"><span></span><span></span><span></span></div><div style="font-size:13px;color:var(--r-text2);margin-top:12px;">Binice analyserar...</div></div>'), 'step3loading');
    analyzeComment(currentComment)
      .then(function(r) { analysisResult = r || fallbackAnalysis(); showStep3(); })
      .catch(function() { analysisResult = fallbackAnalysis(); showStep3(); });
  }

  function fallbackAnalysis() {
    return { highlighted_comment: esc(currentComment), reflection_question: 'Hur tror du att mottagaren upplever kommentaren?', default_suggestion: '' };
  }

  function doConfirmEdit() {
    var el = document.getElementById('r-edit');
    var t = el ? el.value.trim() : '';
    if (!t) return;
    if (t === currentComment) showScreen(htmlUnchanged(), 'unchanged');
    else { currentComment = t; showPublish(); }
  }

  function doGetSuggestion() {
    var el = document.getElementById('r-intention');
    var t = el ? el.value.trim() : '';
    if (!t || t.length < 3) return;
    currentIntention = t;
    doLoadSuggestion();
  }

  function doLoadSuggestion() {
    showScreen(S(3) + wrap('<div style="text-align:center;padding:30px 0 20px;"><div class="reflekt-bee-loading"><img src="' + BEE_URL + '" alt="Binice"></div><div class="reflekt-loading-dots"><span></span><span></span><span></span></div><div style="font-size:13px;color:var(--r-text2);margin-top:12px;">Binice skriver ett f\u00f6rslag...</div></div>'), 'sugLoading');
    generateSuggestion(currentIntention, selectedTone)
      .then(function(s) { showSuggestion(s); })
      .catch(function() { showSuggestion(''); });
  }

  function doUseSuggestion() {
    var el = document.getElementById('r-sug');
    if (el) currentComment = el.value.trim() || currentComment;
    showPublish();
  }

  function doFinalSend() {
    ensureOverlay();
    var panel = document.getElementById('reflekt-panel');
    if (panel) panel.innerHTML = htmlDone();
    // Paste without closing, then close after 5 seconds
    setTimeout(function() { pasteOnly(currentComment); }, 300);
    setTimeout(function() { closeAll(); }, 3000);
  }

  // ─── API ─────────────────────────────────────────────────────────────────────
  async function analyzeComment(text) {
    var stored = await chrome.storage.local.get('apiKey');
    var apiKey = stored.apiKey;
    if (!apiKey) return null;
    var res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 800,
        messages: [{ role: 'user', content: 'Analysera kommentaren fran en klimatdebatt pa Facebook.\n\nReturnera ENDAST JSON:\n{"highlighted_comment":"kommentaren dar aggressiva fraser omges av <span class=\'reflekt-underline-high\'>frasen</span>","reflection_question":"Kort neutral fraga pa svenska.","default_suggestion":"Omformulering. Max 2 meningar."}\n\nKommentar: "' + text.replace(/"/g, '\\"') + '"' }]
      })
    });
    var d = await res.json();
    return JSON.parse((d.content || []).map(function(b) { return b.text || ''; }).join('').replace(/```json|```/g, '').trim());
  }

  async function generateSuggestion(intention, tone) {
    var stored = await chrome.storage.local.get('apiKey');
    var apiKey = stored.apiKey;
    if (!apiKey) return '';
    var toneMap = { saklig: 'saklig och faktabaserad', vanlig: 'vanlig och empatisk', informativ: 'informativ och pedagogisk', fraga: 'nyfiken och fragande' };
    var res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 300,
        messages: [{ role: 'user', content: 'Skriv en ny formulering baserat pa personens intention.\n\nIntention: "' + intention + '"\nTon: ' + (toneMap[tone] || 'balanserad') + '\nOriginal (skriv INTE om denna): "' + currentComment + '"\n\nReturnera ENDAST: {"suggestion":"Ny formulering. Max 2-3 meningar. Svenska."}' }]
      })
    });
    var d = await res.json();
    return JSON.parse((d.content || []).map(function(b) { return b.text || ''; }).join('').replace(/```json|```/g, '').trim()).suggestion;
  }

  // ─── Start ───────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
