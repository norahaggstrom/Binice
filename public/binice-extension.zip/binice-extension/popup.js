// popup.js – laddas av popup.html

document.addEventListener('DOMContentLoaded', function () {
  const input = document.getElementById('api-key');
  const btn = document.getElementById('save-btn');
  const status = document.getElementById('status');

  // Ladda sparad nyckel
  chrome.storage.local.get('apiKey', function (result) {
    if (result.apiKey) {
      input.value = result.apiKey;
      status.textContent = '✓ Nyckel sparad';
      status.className = 'status ok';
    }
  });

  // Spara nyckel
  btn.addEventListener('click', function () {
    const key = input.value.trim();

    if (!key) {
      status.textContent = 'Klistra in din API-nyckel ovan.';
      status.className = 'status err';
      return;
    }

    if (!key.startsWith('sk-ant-')) {
      status.textContent = 'Nyckeln verkar inte stämma – börjar den med sk-ant-?';
      status.className = 'status err';
      return;
    }

    chrome.storage.local.set({ apiKey: key }, function () {
      status.textContent = '✓ Sparad! Gå till Facebook och testa.';
      status.className = 'status ok';
    });
  });

  // Spara även med Enter
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') btn.click();
  });
});
